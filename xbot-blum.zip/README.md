# xbot-blum

Bot automático para publicar desde Blum Records en Twitter/X.

## Configuración
1. Subir este proyecto a GitHub.
2. Crear nuevo servicio en Render llamado `xbot-blum`.
3. En Variables de Entorno (`Environment`), copiar los valores del archivo `.env.example`.
4. Redeploy.

## Publicación
Publica 5 veces al día (12:00, 15:00, 18:00, 21:00, 00:00) leyendo del Sheet `tracks`.
Evita repeticiones durante 70 días.
